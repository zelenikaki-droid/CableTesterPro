package com.cabletester.pro.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.cabletester.pro.model.CableProfile
import com.cabletester.pro.model.PinConnection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.cabletester.pro.repository.ProfileRepository


class MainViewModel(
    private val repository: ProfileRepository
) : ViewModel() {


    var profiles by mutableStateOf(
        repository.loadProfiles()
    )
        private set



    var selectedProfile by mutableStateOf<CableProfile?>(null)
        private set



    init {

        val lastId =
            repository.getLastProfileId()


        selectedProfile =
            profiles.find {

                it.id == lastId

            }

    }




    fun selectProfile(
        profile: CableProfile
    ) {

        selectedProfile = profile

        repository.saveLastProfileId(
            profile.id
        )
    }





    fun addProfile(
        profile: CableProfile
    ) {

        profiles = profiles + profile

        repository.saveProfiles(
            profiles
        )
    }





    fun updateProfile(
        profile: CableProfile
    ) {


        val updatedProfile =
            profile.copy(

                name = profile.articleName

            )


        profiles =
            profiles.map {

                if(it.id == updatedProfile.id)

                    updatedProfile

                else

                    it

            }



        selectedProfile = updatedProfile


        repository.saveProfiles(
            profiles
        )

    }





    fun deleteProfile(
        profile: CableProfile
    ) {


        profiles =
            profiles.filter {

                it.id != profile.id

            }



        if(
            selectedProfile?.id ==
            profile.id
        ){

            selectedProfile = null

        }



        repository.saveProfiles(
            profiles
        )

    }







    fun createProfile() {


        val profile = CableProfile(

            id = System.currentTimeMillis(),

            name = "Nov profil",

            articleCode =
                "NOV-${profiles.size + 1}",

            articleName =
                "Nov profil",

            notes = "",

            created =
                System.currentTimeMillis()
                    .toString()

        )


        addProfile(profile)

        selectProfile(profile)

    }







    fun saveLearnedConnections(

        profile: CableProfile,

        connections: List<PinConnection>

    ) {


        val date = SimpleDateFormat(

            "dd.MM.yyyy HH:mm",

            Locale.getDefault()

        ).format(Date())



        val updatedProfile =

            profile.copy(

                connections = connections,

                referenceLearned = true,

                learnedDate = date

            )



        updateProfile(

            updatedProfile

        )

    }





    fun loadDemoProfiles() {


        if(
            profiles.isNotEmpty()
        )

            return



        addProfile(

            CableProfile(

                id = 1,

                name = "Kabel motorja",

                articleCode = "KAB-001",

                articleName = "Kabel motorja",

                notes = "Demo profil",

                created = "2026-07-21"

            )

        )



        addProfile(

            CableProfile(

                id = 2,

                name = "Adapter DB9",

                articleCode = "DB9-001",

                articleName = "Adapter DB9",

                notes = "Demo profil",

                created = "2026-07-21"

            )

        )

    }

}