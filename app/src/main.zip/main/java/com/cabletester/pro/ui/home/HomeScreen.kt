package com.cabletester.pro.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cabletester.pro.components.ProfileEditor
import com.cabletester.pro.model.CableProfile
import com.cabletester.pro.viewmodel.MainViewModel


@Composable
fun HomeScreen(
    viewModel: MainViewModel
) {


    Row(

        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()

    ) {


        // LEVA STRAN

        Column(

            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .padding(6.dp)

        ) {



            Text(

                text = "Profili",

                style = MaterialTheme.typography.titleMedium

            )



            Spacer(
                modifier = Modifier.height(4.dp)
            )



            Button(

                onClick = {
                    viewModel.createProfile()
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)

            ) {

                Text("+ NOV")

            }



            Spacer(
                modifier = Modifier.height(5.dp)
            )



            var searchText by remember {
                mutableStateOf("")
            }



            OutlinedTextField(

                value = searchText,

                onValueChange = {
                    searchText = it
                },

                label = {
                    Text("Išči")
                },

                singleLine = true,

                modifier = Modifier
                    .fillMaxWidth()

            )



            Spacer(
                modifier = Modifier.height(5.dp)
            )



            Column(

                modifier = Modifier
                    .fillMaxHeight()
                    .verticalScroll(
                        rememberScrollState()
                    )

            ) {


                viewModel.profiles

                    .filter {

                        searchText.isBlank()
                                ||
                                it.articleCode.contains(
                                    searchText,
                                    true
                                )
                                ||
                                it.name.contains(
                                    searchText,
                                    true
                                )

                    }

                    .sortedBy {

                        it.articleCode.lowercase()

                    }

                    .forEach {


                        ProfileItem(

                            profile = it,

                            selected =
                                it.id ==
                                        viewModel.selectedProfile?.id,


                            onClick = {

                                viewModel.selectProfile(it)

                            }

                        )

                    }

            }

        }



        VerticalDivider()



        // DESNA STRAN


        Box(

            modifier = Modifier

                .fillMaxSize()

                .padding(6.dp)

        ) {


            ProfileEditor(

                profile = viewModel.selectedProfile,

                onSave = {

                    viewModel.updateProfile(it)

                },

                onDelete = {

                    viewModel.selectedProfile?.let { profile ->

                        viewModel.deleteProfile(
                            profile
                        )

                    }

                },

                onLearnSave = { connections ->

                    viewModel.selectedProfile?.let { profile ->

                        viewModel.saveLearnedConnections(

                            profile,

                            connections

                        )

                    }

                }

            )

        }

    }

}





@Composable
fun ProfileItem(

    profile: CableProfile,

    selected: Boolean,

    onClick: () -> Unit

) {


    Card(

        modifier = Modifier

            .fillMaxWidth()

            .padding(vertical = 2.dp)

            .clickable {

                onClick()

            }

    ) {


        Column(

            modifier =
                Modifier.padding(6.dp)

        ) {



            Text(

                text = profile.articleCode,

                style =
                    MaterialTheme.typography.labelMedium

            )



            Text(

                text = profile.name,

                style =
                    MaterialTheme.typography.bodyMedium

            )



            if(selected){

                Text(
                    text = "✓",
                    style =
                        MaterialTheme.typography.labelSmall
                )

            }

        }

    }

}