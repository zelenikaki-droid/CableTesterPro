package com.cabletester.pro.model

data class PinConnection(
    val fromPin: Int,
    val toPin: Int
)