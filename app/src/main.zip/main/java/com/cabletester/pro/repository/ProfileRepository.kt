package com.cabletester.pro.repository

import android.content.Context
import com.cabletester.pro.model.CableProfile
import org.json.JSONArray
import org.json.JSONObject


class ProfileRepository(
    context: Context
) {

    private val prefs =
        context.getSharedPreferences(
            "cable_profiles",
            Context.MODE_PRIVATE
        )


    fun saveProfiles(
        profiles: List<CableProfile>
    ) {

        val array = JSONArray()

        profiles.forEach { profile ->

            val obj = JSONObject()

            obj.put("id", profile.id)
            obj.put("name", profile.name)
            obj.put("articleCode", profile.articleCode)
            obj.put("articleName", profile.articleName)
            obj.put("notes", profile.notes)
            obj.put("created", profile.created)
            obj.put("lastTest", profile.lastTest)
            obj.put("referenceLearned", profile.referenceLearned)
            obj.put("imagePath", profile.imagePath)
            obj.put("lastResult", profile.lastResult ?: false)
            obj.put("passedTests", profile.passedTests)
            obj.put("failedTests", profile.failedTests)

            array.put(obj)
        }


        prefs.edit()
            .putString(
                "profiles",
                array.toString()
            )
            .apply()
    }



    fun loadProfiles(): List<CableProfile> {

        val json =
            prefs.getString(
                "profiles",
                null
            )
                ?: return emptyList()


        val array = JSONArray(json)

        val list =
            mutableListOf<CableProfile>()


        for (i in 0 until array.length()) {

            val obj =
                array.getJSONObject(i)


            list.add(

                CableProfile(

                    id = obj.getLong("id"),

                    name = obj.getString("name"),

                    articleCode =
                        obj.getString("articleCode"),

                    articleName =
                        obj.getString("articleName"),

                    notes =
                        obj.getString("notes"),

                    created =
                        obj.getString("created"),

                    lastTest =
                        obj.getString("lastTest"),

                    referenceLearned =
                        obj.getBoolean("referenceLearned"),

                    imagePath =
                        obj.getString("imagePath"),

                    lastResult =
                        if (obj.getBoolean("lastResult"))
                            true
                        else
                            null,

                    passedTests =
                        obj.getInt("passedTests"),

                    failedTests =
                        obj.getInt("failedTests")
                )
            )
        }


        return list
    }
    fun saveLastProfileId(id: Long) {

        prefs.edit()
            .putLong("last_profile_id", id)
            .apply()
    }



    fun getLastProfileId(): Long {

        return prefs.getLong(
            "last_profile_id",
            -1
        )
    }
}