package com.cabletester.pro.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cabletester.pro.model.PinConnection


@Composable
fun SelfLearnScreen(

    articleCode: String,

    articleName: String,

    onSave: (List<PinConnection>) -> Unit,

    onBack: () -> Unit

) {


    var learned by remember {

        mutableStateOf(false)

    }



    // ZAČASNI TESTNI VZOREC
    // kasneje to pride iz Arduina

    val learnedConnections = listOf(

        PinConnection(1, 1),

        PinConnection(2, 2),

        PinConnection(3, 3),

        PinConnection(4, 4),

        PinConnection(5, 5)

    )



    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(20.dp),

        verticalArrangement =
            Arrangement.spacedBy(15.dp)

    ) {



        Text(

            text = articleCode,

            style =
                MaterialTheme.typography.headlineMedium

        )



        Text(

            text = articleName,

            style =
                MaterialTheme.typography.titleLarge

        )



        HorizontalDivider()



        Text(

            text = "▶ SELF LEARN",

            style =
                MaterialTheme.typography.headlineSmall

        )





        if(!learned) {


            Text(

                text =
                    "Priklopi referenčni kabel in zaženi učenje."

            )



            Button(

                onClick = {


                    onSave(
                        learnedConnections
                    )


                    learned = true


                },

                modifier =
                    Modifier.fillMaxWidth()

            ){

                Text("ZAČNI UČENJE")

            }


        } else {



            Text(

                text =
                    "✅ REFERENČNI VZOREC SHRANJEN",

                style =
                    MaterialTheme.typography.titleLarge

            )



            Text(

                text =
                    "Naučenih povezav: ${learnedConnections.size}"

            )

        }





        Spacer(

            modifier =
                Modifier.weight(1f)

        )





        Button(

            onClick = {

                onBack()

            },

            modifier =
                Modifier.fillMaxWidth()

        ){

            Text("NAZAJ")

        }

    }

}