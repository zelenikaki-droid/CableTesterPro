package com.cabletester.pro.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun TestScreen(

    articleCode: String,

    articleName: String,

    onBack: () -> Unit

) {


    var testFinished by remember {
        mutableStateOf(false)
    }


    // ZA TESTIRANJE UI
    // kasneje bo to prišlo iz Arduina

    val testPassed = true


    val errors = listOf(
        "A3 → B5 napačna povezava",
        "A7 → B2 prekinjen vodnik"
    )



    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(20.dp),

        verticalArrangement =
            Arrangement.spacedBy(15.dp)

    ) {



        Text(

            text = articleCode,

            style =
                MaterialTheme.typography.headlineMedium

        )



        Text(

            text = articleName,

            style =
                MaterialTheme.typography.titleLarge

        )



        HorizontalDivider()



        if(!testFinished) {


            Text(

                text = "🔌 TESTIRANJE...",

                style =
                    MaterialTheme.typography.headlineSmall

            )



            Spacer(
                modifier = Modifier.height(20.dp)
            )



            Button(

                onClick = {

                    testFinished = true

                },

                modifier =
                    Modifier.fillMaxWidth()

            ){

                Text("KONČAJ TEST")

            }


        } else {



            if(testPassed) {


                Text(

                    text = "✅ TEST OK",

                    style =
                        MaterialTheme.typography.headlineMedium

                )


            } else {



                Text(

                    text = "❌ TEST NAPAKA",

                    style =
                        MaterialTheme.typography.headlineMedium

                )



                Spacer(
                    modifier =
                        Modifier.height(10.dp)
                )



                Text("Napake:")



                errors.forEach {


                    Text(

                        text = "• $it"

                    )

                }

            }

        }




        Spacer(
            modifier = Modifier.weight(1f)
        )



        Button(

            onClick = {

                onBack()

            },

            modifier =
                Modifier.fillMaxWidth()

        ){

            Text("NAZAJ")

        }

    }

}