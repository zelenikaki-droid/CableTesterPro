package com.cabletester.pro.service

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class BluetoothService {

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    private val uuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun isBluetoothAvailable(): Boolean {
        return adapter != null
    }

    fun isBluetoothEnabled(): Boolean {
        return adapter?.isEnabled == true
    }

    fun pairedDevices(): List<BluetoothDevice> {
        return adapter?.bondedDevices?.toList() ?: emptyList()
    }

    fun connect(device: BluetoothDevice): Boolean {
        return try {
            socket = device.createRfcommSocketToServiceRecord(uuid)
            socket?.connect()

            input = socket?.inputStream
            output = socket?.outputStream

            true
        } catch (e: Exception) {
            false
        }
    }

    fun send(text: String) {
        output?.write(text.toByteArray())
    }

    fun receive(): String {
        val buffer = ByteArray(1024)
        val count = input?.read(buffer) ?: 0
        return String(buffer, 0, count)
    }

    fun disconnect() {
        input?.close()
        output?.close()
        socket?.close()
    }
}