package com.cabletester.pro.components

import com.cabletester.pro.model.PinConnection
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cabletester.pro.model.CableProfile


@Composable
fun ProfileEditor(

    profile: CableProfile?,

    onSave: (CableProfile) -> Unit,

    onDelete: () -> Unit,

    onLearnSave: (List<PinConnection>) -> Unit

) {


    if (profile == null) {

        Text(
            text = "Izberi profil",
            modifier = Modifier.padding(20.dp)
        )

        return
    }



    var showTestScreen by remember {
        mutableStateOf(false)
    }


    var showSelfLearnScreen by remember {
        mutableStateOf(false)
    }



    if(showSelfLearnScreen) {


        SelfLearnScreen(

            articleCode = profile.articleCode,

            articleName = profile.name,


            onSave = { connections ->

                onLearnSave(connections)

            },


            onBack = {

                showSelfLearnScreen = false

            }

        )


        return

    }



    if(showTestScreen) {


        TestScreen(

            articleCode = profile.articleCode,

            articleName = profile.name,


            onBack = {

                showTestScreen = false

            }

        )


        return

    }





    var editMode by remember {

        mutableStateOf(false)

    }



    var articleCode by remember {

        mutableStateOf(profile.articleCode)

    }



    var articleName by remember {

        mutableStateOf(profile.articleName)

    }



    var notes by remember {

        mutableStateOf(profile.notes)

    }





    Column(

        modifier = Modifier

            .fillMaxSize()

            .verticalScroll(
                rememberScrollState()
            )

            .padding(10.dp),

        verticalArrangement =
            Arrangement.spacedBy(10.dp)

    ) {



        Card(

            modifier =
                Modifier.fillMaxWidth()

        ) {


            Column(

                modifier =
                    Modifier.padding(12.dp)

            ) {


                Text(

                    text = profile.articleCode,

                    style =
                        MaterialTheme.typography.headlineSmall

                )


                Text(

                    text = profile.name,

                    style =
                        MaterialTheme.typography.titleLarge

                )

            }

        }





        Spacer(
            modifier = Modifier.height(15.dp)
        )





        Button(

            onClick = {

                showTestScreen = true

            },

            modifier = Modifier

                .fillMaxWidth()

                .height(90.dp)

        ) {


            Text(

                text = "✔ TEST",

                style =
                    MaterialTheme.typography.headlineMedium

            )

        }





        Spacer(
            modifier = Modifier.height(15.dp)
        )





        Card(

            modifier =
                Modifier.fillMaxWidth()

        ) {


            Column(

                modifier =
                    Modifier.padding(12.dp)

            ) {


                Text(
                    text =
                        if(profile.referenceLearned)

                            "Referenčni vzorec: ✅ NAUČEN"

                        else

                            "Referenčni vzorec: ⚪ NI NAUČEN"
                )


                Text(
                    text =
                        "Naučene povezave: ${profile.connections.size}"
                )


                if(profile.referenceLearned) {

                    Text(
                        text =
                            "Zadnje učenje: ${profile.learnedDate}"
                    )

                }



                Text(
                    text =
                        "Zadnji test: ${profile.lastTest}"
                )


                Text(
                    text =
                        "Uspešni testi: ${profile.passedTests}"
                )


                Text(
                    text =
                        "Neuspešni testi: ${profile.failedTests}"
                )

            }

        }





        Button(

            onClick = {

                editMode = !editMode

            },

            modifier =
                Modifier.fillMaxWidth()

        ) {


            Text(

                if(editMode)

                    "⬆ SKRIJ UREJANJE"

                else

                    "⚙ UREDI PROFIL"

            )

        }





        if(editMode) {


            HorizontalDivider()



            Text("Urejanje profila")



            OutlinedTextField(

                value = articleCode,

                onValueChange = {

                    articleCode = it

                },

                label = {

                    Text("Koda artikla")

                },

                modifier =
                    Modifier.fillMaxWidth()

            )



            OutlinedTextField(

                value = articleName,

                onValueChange = {

                    articleName = it

                },

                label = {

                    Text("Naziv artikla")

                },

                modifier =
                    Modifier.fillMaxWidth()

            )



            OutlinedTextField(

                value = notes,

                onValueChange = {

                    notes = it

                },

                label = {

                    Text("Opombe")

                },

                modifier =
                    Modifier.fillMaxWidth()

            )



            Button(

                onClick = {

                    onSave(

                        profile.copy(

                            articleCode = articleCode,

                            articleName = articleName,

                            notes = notes

                        )

                    )

                },

                modifier =
                    Modifier.fillMaxWidth()

            ){

                Text("💾 SHRANI")

            }




            Button(

                onClick = {

                    showSelfLearnScreen = true

                },

                modifier =
                    Modifier.fillMaxWidth()

            ){

                Text("▶ SELF LEARN")

            }





            Button(

                onClick = {

                    onDelete()

                },

                colors =
                    ButtonDefaults.buttonColors(

                        containerColor =
                            MaterialTheme.colorScheme.error

                    ),

                modifier =
                    Modifier.fillMaxWidth()

            ){

                Text("🗑 IZBRIŠI PROFIL")

            }

        }

    }

}